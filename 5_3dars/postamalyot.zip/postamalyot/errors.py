class UsernameAlreadyExistsError(Exception):
    pass