ingredients = "guruch, sabzi, go'sht, yog', ziravorlar"

ingredientsList = ingredients.split()

print(ingredientsList)